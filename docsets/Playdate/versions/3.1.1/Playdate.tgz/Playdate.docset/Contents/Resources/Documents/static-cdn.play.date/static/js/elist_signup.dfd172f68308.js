const elistUrl = document.currentScript.dataset.elistUrl;

function elistSignup(e, source) {
    e.preventDefault();

    const http = new XMLHttpRequest();
    http.open("POST", elistUrl, true);
    http.responseType = "json";

    http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    http.setRequestHeader("X-Requested-With", "XMLHttpRequest");

    const status = document.querySelector("#status");
    const email = this.querySelector('input[type="email"]').value;
    const formData = `email=${email}&source=${window.location.pathname}`;

    http.onreadystatechange = function () {
        if (http.readyState == 4) {
            if (http.status == 200) {
                console.log("Success!", http.response);
                status.classList.add("success");
                status.innerText = "You're subscribed!";
            } else {
                console.log("Error.", http.response);
                status.classList.add("error");
                status.innerText =
                    "Something went wrong. Please try again later.";
            }
        }
    };
    http.send(formData);
}

document.querySelector("#elist_form").addEventListener("submit", elistSignup);
