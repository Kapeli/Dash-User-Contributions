Covered Version
--------------------

This documentation covers PyMuPDF v1.17.0 features as of **2020-04-23 13:05:19**.

.. note:: The major and minor versions of **PyMuPDF** and **MuPDF** will always be the same. Only the third qualifier (patch level) may be different from that of MuPDF.