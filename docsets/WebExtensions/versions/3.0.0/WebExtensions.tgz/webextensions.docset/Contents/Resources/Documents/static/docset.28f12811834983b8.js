// Copy buttons for code examples. navigator.clipboard is unavailable in
// non-secure contexts (docset pages are local files), hence the fallback.
document.addEventListener('click', (event) => {
	const button = event.target.closest('.copy-button');
	if (!button) {
		return;
	}
	const pre = button.closest('.code-example').querySelector('pre');
	if (!pre) {
		return;
	}
	const code = pre.textContent;

	const flash = (label) => {
		button.textContent = label;
		button.classList.add('copy-button--copied');
		setTimeout(() => {
			button.textContent = 'Copy';
			button.classList.remove('copy-button--copied');
		}, 1500);
	};

	const fallbackCopy = () => {
		const textarea = document.createElement('textarea');
		textarea.value = code;
		textarea.style.position = 'fixed';
		textarea.style.opacity = '0';
		document.body.append(textarea);
		textarea.select();
		try {
			document.execCommand('copy');
			flash('Copied!');
		} catch (e) {
			flash('Error');
		}
		textarea.remove();
	};

	if (navigator.clipboard && navigator.clipboard.writeText) {
		navigator.clipboard.writeText(code).then(() => flash('Copied!'), fallbackCopy);
	} else {
		fallbackCopy();
	}
});
