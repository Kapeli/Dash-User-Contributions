***********************
Functions and Operators
***********************

.. toctree::
    :maxdepth: 1

    functions/logical
    functions/comparison
    functions/conditional
    functions/lambda
    functions/conversion
    functions/math
    functions/bitwise
    functions/decimal
    functions/string
    functions/regexp
    functions/binary
    functions/json
    functions/datetime
    functions/aggregate
    functions/noisy
    functions/window
    functions/array
    functions/map
    functions/url
    functions/ip
    functions/geospatial
    functions/hyperloglog
    functions/khyperloglog
    functions/qdigest
    functions/uuid
    functions/tdigest
    functions/color
    functions/session
    functions/teradata
    functions/internationalization
    functions/setdigest
    functions/sketch
    functions/pinot
    functions/plugin-loaded-functions
    functions/table
