=================
Router Schedulers
=================

Presto router provides multiple scheduling algorithms for load balancing across
multiple clusters.

* ``RANDOM_CHOICE``

  Randomly selecting a cluster from a list of candidates.

* ``ROUND_ROBIN``

  Selecting clusters from a list of candidates in turn. Because the algorithm 
  keeps the state of the selected index, it can only be used when the candidates 
  are always consistent.

* ``USER_HASH``

  Selecting a cluster by hashing the username. This ensures queries from the same 
  user are always routed to the same cluster.

* ``WEIGHTED_RANDOM_CHOICE``

  Randomly selecting a cluster from a list of candidates with pre-defined weights. 
  Clusters with higher weights have higher opportunity to be selected.

* ``WEIGHTED_ROUND_ROBIN``

  Selecting clusters from a list of candidates with pre-defined weights in turn. 
  Similar to the `ROUND_ROBIN` approach, this algorithm keeps the state 
  of the selected index so candidates and weights should be consistent.
