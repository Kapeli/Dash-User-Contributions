#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# noinspection PyUnresolvedReferences
from docutils import nodes, utils
# noinspection PyUnresolvedReferences
from sphinx.errors import SphinxError

GROUP_ID = 'com.facebook.presto'
ARTIFACTS = {
    'server': ('presto-server', 'tar.gz', None),
    'cli': ('presto-cli', 'jar', 'executable'),
    'jdbc': ('presto-jdbc', 'jar', None),
    'verifier': ('presto-verifier', 'jar', 'executable'),
    'benchmark-driver': ('presto-benchmark-driver', 'jar', 'executable'),
    'spark-package': ('presto-spark-package', 'tar.gz', None),
    'spark-launcher': ('presto-spark-launcher', 'jar', None),
    'router': ('presto-router', 'tar.gz', None),
    'flightshim': ('presto-flight-shim', 'tar.gz', None),
}


def maven_filename(artifact, version, packaging, classifier):
    classifier = '-' + classifier if classifier else ''
    return '%s-%s%s.%s' % (artifact, version, classifier, packaging)


def maven_download(group, artifact, version, packaging, classifier):
    base = 'https://repo1.maven.org/maven2/'
    group_path = group.replace('.', '/')
    filename = maven_filename(artifact, version, packaging, classifier)
    return base + '/'.join((group_path, artifact, version, filename))

def github_download(group, artifact, version, packaging, classifier):
    base = 'https://github.com/prestodb/presto/releases/download/'
    filename = maven_filename(artifact, version, packaging, classifier)
    return base + '/'.join((version, filename))

def setup(app):
    # noinspection PyDefaultArgument,PyUnusedLocal
    def create_download_role(download_func):
        def download_link_role(role, rawtext, text, lineno, inliner, options={}, content=[]):
            version = app.config.release

            if not text in ARTIFACTS:
                inliner.reporter.error('Unsupported download type: ' + text)
                return [], []

            artifact, packaging, classifier = ARTIFACTS[text]

            title = maven_filename(artifact, version, packaging, classifier)
            uri = download_func(GROUP_ID, artifact, version, packaging, classifier)

            node = nodes.reference(title, title, internal=False, refuri=uri)

            return [node], []
        return download_link_role

    app.add_role('maven_download', create_download_role(maven_download))
    app.add_role('github_download', create_download_role(github_download))

    return {
        'parallel_read_safe': True,
    }
