=========================
Presto Session Properties
=========================

This section describes session properties that may be used to tune
Presto or alter its behavior when required.

The following is not a complete list of all session properties
available in Presto, and does not include any connector-specific
catalog properties.

For information on catalog properties, see the :doc:`connector documentation </connector/>`.

For information on configuration properties, see :doc:`properties`.


.. contents::
    :local:
    :backlinks: none
    :depth: 1

General Properties
------------------

``join_distribution_type``
^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``string``
* **Allowed values:** ``AUTOMATIC``, ``PARTITIONED``, ``BROADCAST``
* **Default value:** ``AUTOMATIC``

The type of distributed join to use.  When set to ``PARTITIONED``, presto will
use hash distributed joins.  When set to ``BROADCAST``, it will broadcast the
right table to all nodes in the cluster that have data from the left table.
Partitioned joins require redistributing both tables using a hash of the join key.
This can be slower (sometimes substantially) than broadcast joins, but allows much
larger joins. In particular broadcast joins will be faster if the right table is
much smaller than the left.  However, broadcast joins require that the tables on the right
side of the join after filtering fit in memory on each node, whereas distributed joins
only need to fit in distributed memory across all nodes. When set to ``AUTOMATIC``,
Presto will make a cost based decision as to which distribution type is optimal.
It will also consider switching the left and right inputs to the join.  In ``AUTOMATIC``
mode, Presto will default to hash distributed joins if no cost could be computed, such as if
the tables do not have statistics.

The corresponding configuration property is :ref:`admin/properties:\`\`join-distribution-type\`\``.


``redistribute_writes``
^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

This property enables redistribution of data before writing. This can
eliminate the performance impact of data skew when writing by hashing it
across nodes in the cluster. It can be disabled when it is known that the
output data set is not skewed in order to avoid the overhead of hashing and
redistributing all the data across the network.

When both ``scale_writers`` and ``redistribute_writes`` are set to ``true``,
``scale_writers`` takes precedence.

The corresponding configuration property is :ref:`admin/properties:\`\`redistribute-writes\`\``.

``scale_writers``
^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

This property enables dynamic scaling of writer tasks based on throughput. When enabled,
Presto automatically adjusts the number of writer tasks to use the minimum necessary
for optimal performance. This can improve resource utilization by scaling out writers
only when needed based on data throughput.

When both ``scale_writers`` and ``redistribute_writes`` are set to ``true``,
``scale_writers`` takes precedence.

The corresponding configuration property is :ref:`admin/properties:\`\`scale-writers\`\``.

``single_node_execution_enabled``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

This property ensures that queries scheduled in this cluster use only a single
node for execution, which may improve performance for small queries which can
be executed within a single node.

The corresponding configuration property is :ref:`admin/properties:\`\`single-node-execution-enabled\`\``.

``offset_clause_enabled``
^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

To enable the ``OFFSET`` clause in SQL query expressions, set this property to ``true``.

The corresponding configuration property is :ref:`admin/properties:\`\`offset-clause-enabled\`\``.

``check_access_control_on_utilized_columns_only``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

Apply access control rules on only those columns that are required to produce the query output.

Note: Setting this property to true with the following kinds of queries:

* queries that have ``USING`` in a join condition
* queries that have duplicate named common table expressions (CTE)

causes the query to be evaluated as if the property is set to false and checks the access control for all columns.

To avoid these problems:

* replace all ``USING`` join conditions in a query with ``ON`` join conditions
* set unique names for all CTEs in a query

The corresponding configuration property is :ref:`admin/properties:\`\`check-access-control-on-utilized-columns-only\`\``.

``always_analyze_create_table_query_enabled``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

When enabled, ``CREATE TABLE AS SELECT IF NOT EXISTS`` statements that target an existing table will still
analyze the inner ``SELECT`` query.

The corresponding configuration property is :ref:`admin/properties:\`\`always-analyze-create-table-query-enabled\`\``.

``max_serializable_object_size``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``long``
* **Default value:** ``1000``

Maximum object size in bytes that can be considered serializable in a function call by the coordinator.

The corresponding configuration property is :ref:`admin/properties:\`\`max-serializable-object-size\`\``.

``max_prefixes_count``
^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``integer``
* **Minimum value:** ``1``
* **Default value:** ``100``

Maximum number of prefixes (catalog/schema/table scopes used to narrow metadata lookups) that Presto generates when querying information_schema.
If the number of computed prefixes exceeds this limit, Presto falls back to a single broader prefix (catalog only).
If it’s below the limit, the generated prefixes are used.

The corresponding configuration property is :ref:`admin/properties:\`\`max-prefixes-count\`\``.

``try_function_catchable_errors``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``string``
* **Default value:** ``""`` (empty string)

A comma-separated list of error code names that the ``TRY()`` function should catch
and return ``NULL`` for, in addition to the default catchable errors (such as
``DIVISION_BY_ZERO``, ``INVALID_CAST_ARGUMENT``, ``INVALID_FUNCTION_ARGUMENT``,
and ``NUMERIC_VALUE_OUT_OF_RANGE``).

This allows users to specify exactly which additional errors ``TRY()`` should suppress.
Error codes are matched by their name (such as ``GENERIC_INTERNAL_ERROR``, ``INVALID_ARGUMENTS``).

Example usage::

    SET SESSION try_function_catchable_errors = 'GENERIC_INTERNAL_ERROR,INVALID_ARGUMENTS';
    SELECT TRY(my_function(x)) FROM table;

The corresponding configuration property is :ref:`admin/properties:\`\`try-function-catchable-errors\`\``.

``field_names_in_json_cast_enabled``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

When enabled, JSON objects are cast to ROW types by matching fields by name instead of position, preventing incorrect results when JSON field order differs.

For more information and examples, see :ref:`functions/json:cast to json`.

Remote Function (RPC) Properties
--------------------------------

These properties control execution of remote (RPC) functions, which dispatch each
invocation to an external service.

``rpc_function_optimizer_enabled``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

Enables the RPC function optimizer, which rewrites RPC function calls to use
asynchronous ``RPCNode`` execution.

``rpc_streaming_mode``
^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``string``
* **Allowed values:** ``PER_ROW``, ``BATCH``, ``AUTOMATIC``
* **Default value:** ``PER_ROW``

Controls how RPC function calls are dispatched. ``PER_ROW`` dispatches each row
individually. ``BATCH`` accumulates rows and dispatches them in batches (see
``rpc_dispatch_batch_size``). ``AUTOMATIC`` is resolved to ``PER_ROW`` or ``BATCH``
at query planning time from the estimated input row count (see
``rpc_batch_min_rows``); if the planner has no row-count estimate, it falls back to
``PER_ROW``. The default deployment resolves ``AUTOMATIC`` to ``PER_ROW``; a
deployment may install a custom ``RpcExecutionPolicy`` to enable stats-driven
resolution.

``rpc_batch_min_rows``
^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``integer``
* **Restrictions:** must be greater than ``0``
* **Default value:** ``2000``

When ``rpc_streaming_mode`` is ``AUTOMATIC``, the estimated input row count at or
above which ``BATCH`` is chosen; below it, ``PER_ROW`` is chosen. Has no effect
unless a deployment installs a stats-driven RPC execution policy: the default
policy ignores this value and always resolves ``AUTOMATIC`` to ``PER_ROW``.

``rpc_dispatch_batch_size``
^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``integer``
* **Default value:** ``128``

Batch size for RPC function dispatch in ``BATCH`` streaming mode. ``0`` collects all
rows and dispatches once at the end; values greater than ``0`` flush every N rows
during input processing.

Spilling Properties
-------------------

``spill_enabled``
^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Try spilling memory to disk to avoid exceeding memory limits for the query.

Spilling works by offloading memory to disk. This process can allow a query with a large memory
footprint to pass at the cost of slower execution times. See :ref:`spill-operations`
for a list of operations that support spilling.

Be aware that this is an experimental feature and should be used with care.

The corresponding configuration property is :ref:`admin/properties:\`\`experimental.spill-enabled\`\``.

``join_spill_enabled``
^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

When ``spill_enabled`` is ``true``, this determines whether Presto will try spilling memory to disk for joins to
avoid exceeding memory limits for the query.

The corresponding configuration property is :ref:`admin/properties:\`\`experimental.join-spill-enabled\`\``.

``aggregation_spill_enabled``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

When ``spill_enabled`` is ``true``, this determines whether Presto will try spilling memory to disk for aggregations to
avoid exceeding memory limits for the query.

The corresponding configuration property is :ref:`admin/properties:\`\`experimental.aggregation-spill-enabled\`\``.

``distinct_aggregation_spill_enabled``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

When ``aggregation_spill_enabled`` is ``true``, this determines whether Presto will try spilling memory to disk for distinct
aggregations to avoid exceeding memory limits for the query.

The corresponding configuration property is :ref:`admin/properties:\`\`experimental.distinct-aggregation-spill-enabled\`\``.

``order_by_aggregation_spill_enabled``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

When ``aggregation_spill_enabled`` is ``true``, this determines whether Presto will try spilling memory to disk for order by
aggregations to avoid exceeding memory limits for the query.

The corresponding configuration property is :ref:`admin/properties:\`\`experimental.order-by-aggregation-spill-enabled\`\``.

``window_spill_enabled``
^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

When ``spill_enabled`` is ``true``, this determines whether Presto will try spilling memory to disk for window functions to
avoid exceeding memory limits for the query.

The corresponding configuration property is :ref:`admin/properties:\`\`experimental.window-spill-enabled\`\``.

``order_by_spill_enabled``
^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

When ``spill_enabled`` is ``true``, this determines whether Presto will try spilling memory to disk for order by to
avoid exceeding memory limits for the query.

The corresponding configuration property is :ref:`admin/properties:\`\`experimental.order-by-spill-enabled\`\``.

``aggregation_operator_unspill_memory_limit``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``data size``
* **Default value:** ``4 MB``

Limit for memory used for unspilling a single aggregation operator instance.

The corresponding configuration property is :ref:`admin/properties:\`\`experimental.aggregation-operator-unspill-memory-limit\`\``.

Task Properties
---------------

``task_concurrency``
^^^^^^^^^^^^^^^^^^^^

* **Type:** ``integer``
* **Restrictions:** must be a power of two
* **Default value:** ``16``

Default local concurrency for parallel operators such as joins and aggregations.
This value should be adjusted up or down based on the query concurrency and worker
resource utilization. Lower values are better for clusters that run many queries
concurrently because the cluster will already be utilized by all the running
queries, so adding more concurrency will result in slow downs due to context
switching and other overhead. Higher values are better for clusters that only run
one or a few queries at a time.

The corresponding configuration property is :ref:`admin/properties:\`\`task.concurrency\`\``.

``task_writer_count``
^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``integer``
* **Restrictions:** must be a power of two
* **Default value:** ``1``

The number of concurrent writer threads per worker per query. Increasing this value may
increase write speed, especially when a query is not I/O bound and can take advantage
of additional CPU for parallel writes (some connectors can be bottlenecked on CPU when
writing due to compression or other factors). Setting this too high may cause the cluster
to become overloaded due to excessive resource utilization.

The corresponding configuration property is :ref:`admin/properties:\`\`task.writer-count\`\``.

``task_partitioned_writer_count``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``integer``
* **Default value:** ``task_writer_count``

Number of local parallel table writer threads per worker for partitioned writes. If not
set, the number set by ``task_writer_count`` will be used. It is required to be a power
of two for a Java query engine.

Optimizer Properties
--------------------

``dictionary_aggregation``
^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Enables optimization for aggregations on dictionaries.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.dictionary-aggregation\`\``.

``optimize_cascading_filters_and_projections``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Coalesce cascading projections by fully inlining deterministic child expressions into the parent
projection (the opposite tradeoff from ``InlineProjections``), and merge an adjacent filter and
projection by inlining the projection's expressions into the filter predicate. This co-locates
shared subexpressions within a single operator so the native (Velox) engine's
common-subexpression elimination can deduplicate them, which matches Velox's preferred
filter-then-project shape. Non-deterministic expressions that are referenced more than once and
inputs to ``TRY(...)`` are never inlined, preserving semantics.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.optimize-cascading-filters-and-projections\`\``.

``optimize_hash_generation``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

Compute hash codes for distribution, joins, and aggregations early during execution,
allowing result to be shared between operations later in the query. This can reduce
CPU usage by avoiding computing the same hash multiple times, but at the cost of
additional network transfer for the hashes. In most cases it will decrease overall
query processing time.

It is often helpful to disable this property when using :doc:`/sql/explain` in order
to make the query plan easier to read.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.optimize-hash-generation\`\``.

``optimize_join_fan_out``
^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Collapse a fan-out equi-join whose preserved side is itself an aggregation grouped by, or an
inner join keyed on, a strict superset of the join keys. The preserved side's non-key columns
are packed with ``array_agg(row(...))`` so the join becomes ``N``-to-``1`` (unique on the join
key), and a local ``UNNEST`` above the join re-expands them, reproducing the original rows.
This moves the row multiplication out of the distributed join (smaller build, less shuffle of
duplicated rows) into a streaming local ``UNNEST``.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.optimize-join-fan-out\`\``.

``pre_aggregate_before_grouping_sets``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

When enabled, inserts a partial aggregation below the ``GroupId`` node in grouping sets
queries to reduce the number of rows that ``GroupId`` multiplies across grouping sets.
The partial aggregation groups by the union of all grouping set columns (the finest
granularity needed), which can drastically reduce the input to ``GroupId``. This is
most effective when the data has high cardinality on the grouping columns, as the
pre-aggregation can significantly reduce the row count before multiplication.

Only applies to decomposable aggregation functions such as ``SUM``, ``COUNT``, ``MIN``,
or ``MAX`` that support partial/intermediate/final splitting.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.pre-aggregate-before-grouping-sets\`\``.

``parallelize_chained_aggregation``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

When enabled, optimizes chained aggregations where the outer grouping keys are a subset of
the inner grouping keys by inserting a local round-robin exchange between the outer PARTIAL
aggregation and the chain leading to the inner FINAL aggregation. This parallelizes the
outer PARTIAL across the local node's drivers when the inner aggregation's parallelism is
below what the node can support — common when the inner grouping keys have low cardinality
and the outer aggregation is CPU-heavy (for example ``approx_percentile``).

For example, in a query like::

    SELECT approx_percentile(s, 0.5)
    FROM (SELECT sum(x) AS s FROM t GROUP BY k1, k2)
    GROUP BY k2

The inner aggregation groups by ``(k1, k2)`` and the outer aggregation groups by ``(k2)``.
Since ``{k2}`` is a subset of ``{k1, k2}``, a local round-robin exchange can be inserted
above the inner aggregation so that the outer PARTIAL fans out across all local drivers
instead of inheriting the inner aggregation's parallelism.

Requirements:

* Outer grouping keys must be a strict subset of inner grouping keys
* Only ``ProjectNode`` and ``ExchangeNode`` may sit between the outer PARTIAL and the inner FINAL

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.parallelize-chained-aggregation\`\``.

``push_aggregation_through_join``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

When an aggregation is above an outer join and all columns from the outer side of the join
are in the grouping clause, the aggregation is pushed below the outer join. This optimization
is particularly useful for correlated scalar subqueries, which get rewritten to an aggregation
over an outer join. For example::

    SELECT * FROM item i
        WHERE i.i_current_price > (
            SELECT AVG(j.i_current_price) FROM item j
                WHERE i.i_category = j.i_category);

Enabling this optimization can substantially speed up queries by reducing
the amount of data that needs to be processed by the join.  However, it may slow down some
queries that have very selective joins.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.push-aggregation-through-join\`\``.

``push_partial_aggregation_through_join``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

When a partial aggregation is above an inner join and all aggregation inputs come from
only one side of the join, the partial aggregation is pushed below the join to that side.
This reduces the amount of data flowing into the join operator, which can improve
performance by allowing the aggregation to pre-reduce data before the join is performed.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.push-partial-aggregation-through-join\`\``.

``push_semi_join_through_union``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

When enabled, pushes semi-joins through ``UNION`` sources so that each union
branch performs the semi-join independently. This can improve performance for
``IN`` and ``EXISTS`` queries where the semi-join probe side is a ``UNION``.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.push-semi-join-through-union\`\``.

``push_projection_through_cross_join``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

When enabled, pushes projection expressions through cross join nodes so that each
expression is evaluated only on the side of the cross join that provides its input
variables. This reduces the number of columns flowing through the cross join and
avoids recomputing expressions on the multiplied output rows.

Only deterministic expressions are pushed. Expressions that reference variables from
both sides of the cross join, or constant expressions, remain above the join.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.push-projection-through-cross-join\`\``.

``push_table_write_through_union``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

Parallelize writes when using ``UNION ALL`` in queries that write data. This improves the
speed of writing output tables in ``UNION ALL`` queries because these writes do not require
additional synchronization when collecting results. Enabling this optimization can improve
``UNION ALL`` speed when write speed is not yet saturated. However, it may slow down queries
in an already heavily loaded system.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.push-table-write-through-union\`\``.

``push_aggregation_through_disjoint_union``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

When enabled, pushes a ``GROUP BY`` aggregation completely below a ``UNION ALL`` whenever at
least one grouping key has a constant value within each branch and those constant values are
distinct across branches. Because every group is then fully contained in a single branch, the
top-level aggregation can be eliminated entirely; each branch computes its own ``SINGLE``-step
aggregation and the results are simply re-unioned.

For example, ``SELECT count(*), x FROM (SELECT 1 x UNION ALL SELECT 2 x) GROUP BY x`` is
rewritten so that the ``count`` is computed independently inside each branch and the two
already-aggregated rows are unioned, with no final aggregation on top.

Only fires for single-grouping-set aggregations with deterministic arguments and at least two
union branches. ``GROUPING SETS``, ``ROLLUP``, ``CUBE``, and global (no-``GROUP BY``)
aggregations are not pushed.

The corresponding configuration property is ``optimizer.push-aggregation-through-disjoint-union``.

``join_reordering_strategy``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``string``
* **Allowed values:** ``AUTOMATIC``, ``ELIMINATE_CROSS_JOINS``, ``NONE``
* **Default value:** ``AUTOMATIC``

The join reordering strategy to use.  ``NONE`` maintains the order the tables are listed in the
query.  ``ELIMINATE_CROSS_JOINS`` reorders joins to eliminate cross joins where possible and
otherwise maintains the original query order. When reordering joins it also strives to maintain the
original table order as much as possible. ``AUTOMATIC`` enumerates possible orders and uses
statistics-based cost estimation to determine the least cost order. If stats are not available or if
for any reason a cost could not be computed, the ``ELIMINATE_CROSS_JOINS`` strategy is used.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.join-reordering-strategy\`\``.

``confidence_based_broadcast``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Enable broadcasting based on the confidence of the statistics that are being used, by
broadcasting the side of a joinNode which has the highest (``HIGH`` or ``FACT``) confidence statistics.
If both sides have the same confidence statistics, then the original behavior will be followed.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.confidence-based-broadcast\`\``.

``treat-low-confidence-zero-estimation-as-unknown``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Enable treating ``LOW`` confidence, zero estimations as ``UNKNOWN`` during joins.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.treat-low-confidence-zero-estimation-as-unknown\`\``.

``retry-query-with-history-based-optimization``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Enable retry for failed queries who can potentially be helped by HBO.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.retry-query-with-history-based-optimization\`\``.

``optimizer_inner_join_pushdown_enabled``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Enable push down inner join predicates to database. Only allows equality joins to be pushed down.
Use :ref:`admin/properties-session:\`\`optimizer_inequality_join_pushdown_enabled\`\`` along with this configuration to push down inequality join predicates.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.inner-join-pushdown-enabled\`\``.

``optimizer_inequality_join_pushdown_enabled``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Enable push down inner join inequality predicates to database. For this configuration to be enabled, :ref:`admin/properties-session:\`\`optimizer_inner_join_pushdown_enabled\`\`` should be set to ``true``.
The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.inequality-join-pushdown-enabled\`\``.

``rewrite_bucketed_semi_join_to_join``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

When both sides of a semi-join are backed by tables bucketed on the semi-join key,
rewrite the ``SemiJoinNode`` to a colocated ``LEFT JOIN`` with a ``DISTINCT`` on the
right side. This avoids data shuffle since both sides are already co-partitioned by
the join key.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.rewrite-bucketed-semi-join-to-join\`\``.

``simplify_aggregations_over_constant``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

When enabled, replaces supported aggregation functions over constant arguments
with constant expressions. This can improve performance for queries that apply
aggregations such as ``MIN``, ``MAX``, ``ARBITRARY``, or ``APPROX_DISTINCT`` to
constant inputs.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.simplify-aggregations-over-constant\`\``.

``simplify_coalesce_over_join_keys``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

When enabled, simplifies redundant ``COALESCE`` expressions over equi-join keys
based on join type. This can produce simpler plans and enable additional join
optimizations, including bucketed join optimizations.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.simplify-coalesce-over-join-keys\`\``.

``verbose_optimizer_info_enabled``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Use this and ``optimizers_to_enable_verbose_runtime_stats`` in development to collect valuable debugging information about the optimizer.

Set to ``true`` to use as shown in this example:

``SET SESSION verbose_optimizer_info_enabled=true;``

``optimizers_to_enable_verbose_runtime_stats``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``string``
* **Allowed values:** ``ALL``, an optimizer rule name, or multiple comma-separated optimization rule names
* **Default value:** ``none``

Use this and ``verbose_optimizer_info_enabled`` in development to collect valuable debugging information about the optimizer.

Run the following command to use ``optimizers_to_enable_verbose_runtime_stats``:

``SET SESSION optimizers_to_enable_verbose_runtime_stats=ALL;``

``pushdown_subfields_for_map_functions``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
* **Type:** ``boolean``
* **Default value:** ``true``

Use this to optimize the ``map_filter()`` and ``map_subset()`` function.

It controls if subfields access is executed at the data source or not.

``pushdown_subfields_for_cardinality``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
* **Type:** ``boolean``
* **Default value:** ``false``

Enable subfield pruning for the ``cardinality()`` function to skip reading keys and values.

When enabled, the query optimizer can push down subfield pruning for cardinality operations,
allowing the data source to skip reading the actual keys and values when only the cardinality
(count of elements) is needed.

``schedule_splits_based_on_task_load``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
* **Type:** ``boolean``
* **Default value:** ``false``

If true then splits are scheduled to the tasks based on task load, rather than on the node load.
This is particularly useful for the native worker as it runs splits for tasks differently than the java worker.
The corresponding configuration property is :ref:`admin/properties:\`\`node-scheduler.max-splits-per-task\`\``.

Set to ``true`` to use as shown in this example:

``SET SESSION schedule_splits_based_on_task_load=true;``

``table_scan_shuffle_parallelism_threshold``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``double``
* **Default value:** ``0.1``

Parallelism threshold for adding a shuffle above table scan. When the table's parallelism factor
is below this threshold (0.0-1.0) and ``table_scan_shuffle_strategy`` is ``COST_BASED``,
a round-robin shuffle exchange is added above the table scan to redistribute data.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.table-scan-shuffle-parallelism-threshold\`\``.

``table_scan_shuffle_strategy``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``string``
* **Allowed values:** ``DISABLED``, ``ALWAYS_ENABLED``, ``COST_BASED``
* **Default value:** ``DISABLED``

Strategy for adding shuffle above table scan to redistribute data. When set to ``DISABLED``,
no shuffle is added. When set to ``ALWAYS_ENABLED``, a round-robin shuffle exchange is always
added above table scans. When set to ``COST_BASED``, a shuffle is added only when the table's
parallelism factor is below the ``table_scan_shuffle_parallelism_threshold``.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.table-scan-shuffle-strategy\`\``.

``remote_function_names_for_fixed_parallelism``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``string``
* **Default value:** ``""`` (empty string, disabled)

A regular expression pattern to match fully qualified remote function names, such as ``catalog.schema.function_name``,
that should use fixed parallelism. When a remote function matches this pattern, the optimizer inserts
round-robin shuffle exchanges before and after the projection containing the remote function call.
This ensures that the remote function executes with a fixed degree of parallelism, which can be useful
for controlling resource usage when calling external services.

This property only applies to external/remote functions (functions where ``isExternalExecution()`` returns ``true``,
such as functions using THRIFT, GRPC, or REST implementation types).

Example patterns:

* ``myschema.myfunction`` - matches an exact function name
* ``catalog.schema.remote_.*`` - matches all functions starting with ``remote_`` in the specified catalog and schema
* ``.*remote.*`` - matches any function containing ``remote`` in its fully qualified name

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.remote-function-names-for-fixed-parallelism\`\``.

``remote_function_fixed_parallelism_task_count``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``integer``
* **Default value:** ``null`` (uses the default hash partition count)

The number of tasks to use for remote functions matching the ``remote_function_names_for_fixed_parallelism`` pattern.
When set, this value determines the degree of parallelism for the round-robin shuffle exchanges inserted
around matching remote function projections. If not set, the default hash partition count will be used.

This property is only effective when ``remote_function_names_for_fixed_parallelism`` is set to a non-empty pattern.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.remote-function-fixed-parallelism-task-count\`\``.

``skip_pushdown_through_exchange_for_remote_projection``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

When enabled, skips pushing remote projections through exchange nodes. This can
preserve exchanges around projections that call external functions, where fixed
parallelism or exchange placement is needed to control execution.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.skip-pushdown-through-exchange-for-remote-projection\`\``.

``local_exchange_parent_preference_strategy``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``string``
* **Allowed values:** ``ALWAYS``, ``NEVER``, ``AUTOMATIC``
* **Default value:** ``ALWAYS``

Strategy to consider parent preferences when adding local exchange partitioning for aggregations.
When set to ``ALWAYS``, the optimizer always uses parent preferences for local exchange partitioning.
When set to ``NEVER``, it never uses parent preferences and instead uses the aggregation's own
grouping keys. When set to ``AUTOMATIC``, the optimizer makes a cost-based decision, using parent
preferences only when the estimated partition cardinality is greater than or equal to the task
concurrency.

The corresponding configuration property is :ref:`admin/properties:\`\`optimizer.local-exchange-parent-preference-strategy\`\``.

``join_prefilter_build_side_with_complex_probe_side``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Extends the ``join_prefilter_build_side`` optimization to clone more complex probe-side
patterns (``UNION ALL``, cross join, ``UNNEST``, aggregation) when building the prefilter,
and to push the prefilter ``SemiJoin`` below right-side aggregations so the build side is
filtered before grouping. Only takes effect when ``join_prefilter_build_side`` is also
enabled. Disabled by default because cloning additional probe-side work adds planning
and runtime overhead, which only pays off when the build side is large enough to dominate
the join cost.

The corresponding configuration property is ``optimizer.join-prefilter-build-side-with-complex-probe-side``.

``push_filter_through_selecting_aggregation``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Pushes HAVING-style filters on the output of single-value-selecting aggregates (``MAX``,
``MIN``) below the aggregation when the predicate direction matches the aggregate's
selection semantics. For example, ``HAVING max(x) >= 1.0`` becomes ``WHERE x >= 1.0``.
Only fires when the aggregation has a single aggregate (so filtering rows below the
aggregation does not change the row set seen by other aggregates), the aggregate
argument is a direct column reference (no expressions, ``DISTINCT``, ``FILTER``,
``MASK``, or ``ORDER BY``), and the non-aggregate side of the comparison is evaluable
below the aggregation (literals, grouping keys, raw source columns).

Strict-direction predicates are pushed in REPLACE form: ``MAX`` with ``>`` / ``>=`` and
``MIN`` with ``<`` / ``<=``.

Equality on ``MAX`` / ``MIN`` is pushed in ADD-pre-filter + KEEP-HAVING form:
``HAVING max(x) = c`` becomes ``WHERE x >= c`` below the aggregation while keeping
``HAVING max(x) = c`` above; symmetric for ``MIN`` (``WHERE x <= c``). The relaxed
pre-filter is implied by the original predicate, and the kept HAVING still rejects
groups that would have failed it originally.

``optimize_row_in_predicate``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Rewrites ``ROW(c1, c2, ...) IN (ROW(v1_1, v1_2, ...), ROW(v2_1, v2_2, ...), ...)`` to add per-column
``IN`` predicates (``c1 IN (v1_1, v2_1, ...) AND c2 IN (v1_2, v2_2, ...) AND ...``) alongside the original
disjunctive OR of AND clauses expansion. ``ROW NOT IN`` is rewritten symmetrically with per-column ``NOT IN``
disjuncts plus the original ``ROW NOT IN`` as a safety net. The added simple predicates help the domain
translator extract per-column constraints for optimization. Only fires when the filter sits on a table scan
(optionally through projections), and runs once before table layout selection. This optimization is
flag-controlled and adds a small overhead from the extra predicates.


JDBC Properties
---------------


``useJdbcMetadataCache``
^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Cache the result of the JDBC queries that fetch metadata about tables and columns.

``allowDropTable``
^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Allow connector to drop tables.

``metadataCacheTtl``
^^^^^^^^^^^^^^^^^^^^

* **Type:** ``Duration``
* **Default value:** ``0``

Setting a duration controls how long to cache data.

``metadataCacheRefreshInterval``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``Duration``
* **Default value:** ``0``

``metadataCacheMaximumSize``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``long``
* **Default value:** ``1``

``metadataCacheThreadPoolSize``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``int``
* **Default value:** ``1``

The value represents the max background fetch threads for refreshing metadata.

``validateConnection``
^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

When enabled, the JDBC driver executes a validation query (``SELECT 1``) immediately 
after establishing a connection to ensure it is working properly before returning it 
to the application. This is useful for applications using connection pooling or 
experiencing intermittent connectivity issues, as it allows early detection of failed 
connections rather than discovering connection problems during the first query execution.

To enable connection validation, add ``validateConnection=true`` to the JDBC connection URL::

    jdbc:presto://localhost:8080?validateConnection=true

Or set it by using connection properties::

    Properties properties = new Properties();
    properties.setProperty("user", "test");
    properties.setProperty("validateConnection", "true");
    Connection connection = DriverManager.getConnection(url, properties);

.. note::

    Enabling connection validation adds a small overhead during connection establishment 
    due to the execution of the validation query. This is typically negligible but should 
    be considered in high-frequency connection scenarios.


Query Manager Properties
------------------------

``query_client_timeout``
^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``Duration``
* **Default value:** ``5m``

This property can be used to configure how long a query runs without contact
from the client application, such as the CLI, before it's abandoned.

The corresponding configuration property is :ref:`admin/properties:\`\`query.client.timeout\`\``.

``query_priority``
^^^^^^^^^^^^^^^^^^

* **Type:** ``int``
* **Default value:** ``1``

This property defines the priority of queries for execution and plays an important role in query admission.
Queries with higher priority are scheduled first than the ones with lower priority. Higher number indicates higher priority.

``query_max_queued_time``
^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``Duration``
* **Default value:** ``100d``

Use to configure how long a query can be queued before it is terminated.

The corresponding configuration property is :ref:`admin/properties:\`\`query.max-queued-time\`\``.

View and Materialized View Properties
--------------------------------------

``default_view_security_mode``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``string``
* **Allowed values:** ``DEFINER``, ``INVOKER``
* **Default value:** ``DEFINER``

Sets the default security mode for views and materialized views when the ``SECURITY``
clause is not explicitly specified in ``CREATE VIEW`` or ``CREATE MATERIALIZED VIEW``
statements.

* ``DEFINER``: Views execute with the permissions of the user who created them
* ``INVOKER``: Views execute with the permissions of the user querying them

The corresponding configuration property is :ref:`admin/properties:\`\`default-view-security-mode\`\``.

``legacy_materialized_views``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

Use legacy materialized views implementation. Set to ``false`` to enable the new materialized
views implementation with security modes (DEFINER and INVOKER), automatic query rewriting, and
freshness tracking.

By default, this session property is locked to the server configuration value and cannot be
changed. To allow runtime toggling of this property (for testing/migration purposes only),
set :ref:`admin/properties:\`\`experimental.allow-legacy-materialized-views-toggle\`\`` = ``true``
in the server configuration.

The corresponding configuration property is :ref:`admin/properties:\`\`experimental.legacy-materialized-views\`\``.

``materialized_view_query_rewrite_cost_based_selection_enabled``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Enable cost-based selection when multiple materialized views are available for query
rewriting. When enabled, the optimizer evaluates all compatible materialized view rewrites
and selects the plan with the lowest estimated cost, instead of using the first compatible
view.

The corresponding configuration property is
:ref:`admin/properties:\`\`materialized-view-query-rewrite-cost-based-selection-enabled\`\``.

``materialized_view_stale_read_behavior``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``string``
* **Default value:** ``USE_VIEW_QUERY``

Controls behavior when a materialized view is stale and no per-view staleness config is set.
Valid values are ``FAIL`` (throw an error) or ``USE_VIEW_QUERY`` (query base tables instead).

The corresponding configuration property is :ref:`admin/properties:\`\`materialized-view-stale-read-behavior\`\``.

``materialized_view_default_refresh_type``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``string``
* **Default value:** ``FULL``

Controls the default refresh strategy for materialized views when not specified on the view itself.
Valid values are ``FULL`` (recompute entire view) or ``INCREMENTAL`` (only refresh stale partitions).

Incremental refresh requires a partition-aligned materialized view with identity-transformed
partition columns. See :ref:`iceberg-incremental-refresh` for connector-specific requirements.

.. warning::

    Materialized views are experimental. The SPI and behavior may change in future releases.

``optimizer.optimize_multiple_approx_distinct_on_same_type``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Enable optimization to combine multiple :func:`!approx_distinct` function calls on expressions
of the same type into a single aggregation using ``set_agg`` with array operations (``array_constructor``, ``array_transpose``).

``optimizer.merge_max_by_and_min_by_aggregations``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Enable optimization to merge multiple ``max_by`` or ``min_by`` aggregations that share the same
comparison key into a single aggregation with a ``ROW`` argument. This reduces computational
overhead by performing only one comparison operation per row instead of N comparisons, and
improves memory efficiency by maintaining a single aggregation state instead of N separate states.

For example, when enabled, the following query::

    SELECT max_by(v1, k), max_by(v2, k), max_by(v3, k) FROM table

is internally optimized to use a single ``max_by(ROW(v1, v2, v3), k)`` call with field extraction,
reducing both CPU and memory usage.

``pull_constant_projection_above_exchange``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Pull constant assignments in projections above remote exchanges so that constant values are not
serialized and shuffled across the network. When enabled, constants produced by a ``ProjectNode``
directly below a remote ``ExchangeNode`` are moved to a new ``ProjectNode`` above the exchange,
narrowing the exchange output layout. Constants used in partitioning, hashing, or ordering are not
pulled up, and for multi-source (``UNION``) exchanges only constants that are identical across all
sources are pulled up. This is the session-level counterpart of the configuration property
:ref:`admin/properties:\`\`optimizer.pull-constant-projection-above-exchange\`\``.

``pull_row_local_chain_above_exchange_strategy``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``varchar``
* **Allowed values:** ``DISABLED``, ``ALWAYS_ENABLED``, ``COST_BASED``
* **Default value:** ``DISABLED``

Strategy for pulling a chain of row-local operators (``UNNEST`` and deterministic projections) above a
repartitioning remote ``ExchangeNode`` so the exchange shuffles the smaller pre-expansion input rather
than the post-expansion (fanned-out and widened) rows. With ``ALWAYS_ENABLED`` the rewrite is applied
whenever it is legal (every partitioning, hashing, or ordering variable is produced unchanged below the
chain), independent of cost or statistics. ``COST_BASED`` currently behaves like ``ALWAYS_ENABLED``;
cost-based selection is a separate layer to be added later. This is the session-level counterpart of the
configuration property
:ref:`admin/properties:\`\`optimizer.pull-row-local-chain-above-exchange-strategy\`\``.

``grouped_execution``
^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``true``

Use grouped execution when possible. Grouped execution schedules bucketed table operations
in lifespans (one per bucket), reducing memory usage by processing a subset of data at a time.
This is required for queries on bucketed tables that use join, aggregation, or window functions
with compatible bucket layouts.

The corresponding configuration property is :ref:`admin/properties:\`\`grouped-execution-enabled\`\``.

``partition_aware_grouped_execution``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

When enabled alongside ``grouped_execution``, schedules each (bucket, partition-values) pair as
a separate lifespan instead of processing all partitions per bucket in a single lifespan. This
reduces per-lifespan hash table size for joins and aggregations on bucketed + partitioned tables.

For example, with 8 buckets and 3 ``ds`` partitions, standard grouped execution creates 8 lifespans
(one per bucket, each processing all 3 partitions). Partition-aware grouped execution creates 24
lifespans (8 buckets x 3 partitions), each processing one bucket for one partition value.

The feature activates when:

* The table is both bucketed and partitioned
* Partition columns appear as equi-join keys (for example, ``t1.ds = t2.ds``) or GROUP BY keys
* At least 2 distinct partition values exist (single partition provides no benefit)

When partition-aware execution is not applicable (for example: non-partitioned tables, no partition
columns in join conditions), the query falls back to standard grouped execution automatically.

The corresponding configuration property is :ref:`admin/properties:\`\`partition-aware-grouped-execution-enabled\`\``.

``grouped_execution_when_capable``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

When enabled alongside ``grouped_execution``, runs grouped execution for any grouped-execution-capable
(bucketed) fragment even when no downstream operator makes grouping individually beneficial. Normally
grouped execution engages only when an operator such as a colocated join or a final aggregation on the
bucket key makes it worthwhile; with this property a bucketed scan that merely feeds a shuffle (for
example a join or aggregation on a non-bucket key), or a bucketed-to-bucketed table write, also runs one
bucket per lifespan -- avoiding a re-partition of already-bucketed data and bounding per-lifespan memory
to a single bucket.

Grouping a capable fragment is always correct, but reading fewer buckets at a time can reduce scan
parallelism, so it is most beneficial for memory- or aggregation-bound workloads and may regress
scan-throughput-bound queries. It is disabled by default.

The corresponding configuration property is :ref:`admin/properties:\`\`grouped-execution-when-capable-enabled\`\``.

Geometry Properties
-------------------

``legacy_st_equals``
^^^^^^^^^^^^^^^^^^^^

* **Type:** ``boolean``
* **Default value:** ``false``

Enable legacy behavior for the ``ST_Equals`` geospatial function.
See ``ST_Equals`` in :ref:`functions/geospatial:Relationship Tests` for details on the behavior differences.

The corresponding configuration property is :ref:`admin/properties:\`\`legacy-st-equals\`\``.
