=========
Ecosystem
=========

Overview
--------

Here are some projects that support Presto:

* `APIJSON <https://github.com/Tencent/APIJSON>`_ : A JSON Transmission Protocol and an ORM Library that provides APIs and Docs without writing any code.

* `Hibernate <https://github.com/hibernate/hibernate-orm>`_ : Hibernate's core Object/Relational Mapping functionality.
